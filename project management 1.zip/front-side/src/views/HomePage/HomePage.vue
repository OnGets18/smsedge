<template>
  <div class="homePageWrapper">
    <div class="leftHomePage">
      <HomePageContentBlock
        title="Build your ideal workflow and save more time"
        paragraph="Create customizable automations and integrate all your favorite
        apps to build workflows that make work management
        easier and help your organization thrive."
      />

      <HomePageContentBlock
        title="Optimize your work processes and accomplish more"
        paragraph="Improve your business management by easily monitoring everything from
        budget planning to sales, getting a clear overview of your progress, and
        making informed data-driven decisions."
      />

      <HomePageContentBlock
        title="Boost team collaboration
               and improve productivity"
        paragraph="Simplify communication across teams and hit goals faster, with team
                   management software that maximizes productivity and empowers everyone to work smarter together."
      />
    </div>
    <div class="rightHomePage">
      <h3>START WITH :</h3>
      <RouterLink class="active" to="/">HOME PAGE</RouterLink>
      <RouterLink to="/projects-list">PROJECTS LIST</RouterLink>
      <RouterLink to="/add-project">ADD NEW PROJECT</RouterLink>
    </div>
  </div>
</template>

<script setup>
import HomePageContentBlock from "@/components/pagesComponents/HomePage/HomePageContentBlock.vue";
import { RouterLink } from "vue-router";
</script>

<style scoped lang="scss" src="./HomePage.scss" />
