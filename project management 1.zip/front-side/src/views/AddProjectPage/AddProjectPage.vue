<template>
  <div class="addTaskWrapper">
    <RegularTitle msg="Add new project" />

    <div class="inputsWrapper">
      <div class="input">
        <label for="fname">Project Name</label>
        <input
          v-model="projectObj.name"
          type="text"
          name="title_name"
          placeholder="project name.."
        />
      </div>

      <div class="input">
        <label for="lname">Project Description</label>
        <input
          v-model="projectObj.desc"
          type="text"
          placeholder="Project Description.."
        />
      </div>

      <div class="tasksWrapper">
        <transition-group name="task" tag="div">
          <h2 v-if="projectObj.tasks_list.length">Tasks List:</h2>
          <div
            v-for="(task, index) in projectObj.tasks_list"
            :key="index"
            class="input"
          >
            <label :for="'task' + index">Task {{ index + 1 }}</label>
            <input
              v-model="task.task_name"
              type="text"
              :name="'task' + index"
              placeholder="Task name.."
            />
            <button @click="removeTask(index)">Remove</button>
          </div>
        </transition-group>

        <button class="addTaskBtn" @click="addTask">Add Task</button>
      </div>

      <div class="newProjectBtn" @click="sendMessage" v-show="projectObj.name">
        Create new project
      </div>

      <div class="typeForShowLabel" v-show="projectObj.name === ''">
        Type project name for save...
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from "vue";
import websocketService from "@/services/websocketService/websocketService.js";
import RegularTitle from "@/components/General/Titles/RegularTitle.vue";

const projectObj = ref({
  name: "",
  desc: "",
  tasks_list: [],
});
const addTask = () => {
  projectObj.value.tasks_list.push({ task_name: "" });
};
const removeTask = (index) => {
  projectObj.value.tasks_list.splice(index, 1);
};
const sendMessage = () => {
  websocketService.sendMessage("newProject", projectObj.value);
  projectObj.value.name = "";
  projectObj.value.desc = "";
  projectObj.value.tasks_list = [];
};
</script>

<style scoped lang="scss" src="./AddProjectPage.scss" />
