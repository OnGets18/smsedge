<template>
  <div class="taskListWrapper">
    <RegularTitle msg="Projects List Page" />
    <ProjectListItems v-if="!projectListEmpty" />

    <div class="projectsListEmptyWrapper" v-if="projectListEmpty">
      <h3>Projects List Empty</h3>
      <RouterLink to="/add-project">CLICK FOR NEW PROJECT</RouterLink>
    </div>
  </div>
</template>

<script setup>
import RegularTitle from "@/components/General/Titles/RegularTitle.vue";
import ProjectListItems from "@/components/pagesComponents/ProjectsList/ProjectListItems.vue";
import { computed } from "vue";
import { useStore } from "@/stores/store.js";
import { RouterLink } from "vue-router";
const projectListEmpty = computed(() => {
  return useStore().projectList?.length === 0;
});
</script>

<style lang="scss" src="./ProjectsListPage.scss" />
