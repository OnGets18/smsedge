<template>
  <div class="pagesWrapper">
    <NavHeader />
    <MainTitle msg="Management Projects - Systems" />

    <div class="pageWrapper">
      <router-view v-slot="{ Component, route }">
        <transition name="fade" mode="out-in">
          <component :is="Component" :key="route.fullPath" />
        </transition>
      </router-view>
    </div>
    <Transition name="fade">
      <BaseModal v-if="modalActive" />
    </Transition>
  </div>
</template>

<script setup>
import { RouterView } from "vue-router";
import MainTitle from "./components/General/MainTite/MainTitle.vue";
import NavHeader from "@/components/Layouts/NavHeader/NavHeader.vue";
import { computed, onMounted } from "vue";
import websocketService from "@/services/websocketService/websocketService.js";
import BaseModal from "@/components/Layouts/Modals/BaseModal.vue";
import { useStore } from "@/stores/store.js";

const modalActive = computed(() => {
  return useStore().editModalOpen.active;
});
onMounted(() => {
  useStore().initFromDb();
  websocketService.connect().on("newProject", (data) => {
    console.log("WebSocket newProject received:", data);
    useStore().projectsListMap.set(data.id, {
      id: data.id,
      name: data.name,
      desc: data.desc,
      tasksList: data.tasks_list,
    });
  });

  websocketService.connect().on("editProject", (data) => {
    console.log("WebSocket editProject received:", data);
    useStore().projectsListMap.set(data.id, {
      id: data.id,
      name: data.name,
      desc: data.desc,
      tasksList: data.tasks_list,
    });
  });

  websocketService.connect().on("removeProject", (projectId) => {
    console.log("WebSocket remove received project:", projectId);
    useStore().projectsListMap.delete(projectId);
  });
});
</script>

<style scoped>
.pagesWrapper {
  height: 100vh;

  .pageWrapper {
    min-height: 650px;
    padding: 10px 0 100px 0;
  }
}

@media (min-width: 1024px) {
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.5s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>
