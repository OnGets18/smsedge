import { createRouter, createWebHistory } from "vue-router";
import ProjectsList from "@/views//ProjectsListPage/ProjectsListPage.vue";
import HomePage from "@/views/HomePage/HomePage.vue";
import AddProjectPage from "@/views/AddProjectPage/AddProjectPage.vue";

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: "/",
      name: "homePage",
      component: HomePage,
    },
    {
      path: "/projects-list",
      name: "projectsList",
      component: ProjectsList,
    },
    {
      path: "/add-project",
      name: "AddProjectPage",
      component: AddProjectPage,
    },
  ],
});

export default router;
