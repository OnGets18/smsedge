import { io } from 'socket.io-client';

class WebSocketService {
    constructor() {
        this.url = "http://localhost:3000";
        this.socket = null;
    }

    connect() {
        this.socket = io(this.url);

        this.socket.on('connect', () => {
            console.log('WebSocket connection opened');
        });

        this.socket.on('disconnect', () => {
            console.log('WebSocket connection closed');
        });

        this.socket.on('connect_error', (error) => {
            console.error('WebSocket error:', error);
        });

        return this.socket;
    }

    sendMessage(event, message) {
        if (this.socket) {
            this.socket.emit(event, message);
        } else {
            console.error('WebSocket is not connected');
        }
    }
}

const websocketService = new WebSocketService();
export default websocketService;
