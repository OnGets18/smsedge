<template>
  <i :class="`fa fa-${name}`" :style="{ fontSize: `${size}px` }"></i>
</template>

<script setup>
defineProps({
  name: { type: String, required: true },
  size: { type: String, default: "16" },
});
</script>
