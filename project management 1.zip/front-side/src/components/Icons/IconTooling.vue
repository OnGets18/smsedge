<template>
  <i class="fa fa-cubes"></i>
</template>
