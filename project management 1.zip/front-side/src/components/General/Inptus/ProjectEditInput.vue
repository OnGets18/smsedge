<template>
  <div class="inputsWrapper">
    <div class="input">
      <label for="fname">Project Name</label>
      <input
        v-model="projectObj.name"
        type="text"
        name="title_name"
        placeholder="title name.."
        required
      />
    </div>

    <div class="input">
      <label for="lname">Project Description</label>
      <input
        v-model="projectObj.desc"
        type="text"
        placeholder="Description name.."
        required
      />
    </div>
    <div class="tasksWrapper">
      <div
        v-for="(task, index) in projectObj.tasks_list"
        :key="index"
        class="input"
      >
        <label :for="'task' + index">Task {{ index + 1 }}</label>
        <input v-model="task.task_name" type="text" :name="'task' + index" />
      </div>
    </div>
    <button
      class="actionBtn"
      @click="editProject"
      v-bind="{ disabled: !requiredFieldActive }"
      v-text="actionLabel"
    />
  </div>
</template>

<script setup>
import { computed, ref, watch } from "vue";
import websocketService from "@/services/websocketService/websocketService.js";
import { useStore } from "@/stores/store.js";

const emit = defineEmits(["close"]);

const handleClose = () => {
  emit("close");
};

const projectObj = ref({
  name: useStore()?.selectionProject.name,
  desc: useStore()?.selectionProject.desc,
  tasks_list: useStore()?.selectionProject?.tasksList ?? [],
  id: useStore()?.selectionProjectId,
});

const editProject = () => {
  websocketService.sendMessage("editProject", projectObj.value);
  handleClose();
};

const requiredFieldActive = computed(() => {
  return projectObj.value.name !== "";
});

const actionLabel = computed(() => {
  return requiredFieldActive.value ? "Edit Project" : "Disable Action";
});

watch(
  () => useStore().selectionProject,
  () => {
    console.log("modal edit open , and update");
    alert("Hay ! - Someone else edited your project");
    projectObj.value.name = useStore().selectionProject.name;
    projectObj.value.desc = useStore().selectionProject.desc;
    projectObj.value.tasks_list = useStore().selectionProject.tasksList;
  },
);
</script>

<style scoped lang="scss">
.inputsWrapper {
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 80%;
  margin: 0 auto;

  .input {
    margin-bottom: 25px;
    width: 100%;

    label {
      text-align: left;
      display: block;
      margin-top: 10px;
      font-size: 14px;
    }
    input[type="text"] {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: inline-block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }
  }

  .actionBtn {
    background-color: var(--gereen-style-cust-1);
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 20px;
    cursor: pointer;
    width: 256px;

    &:disabled {
      cursor: not-allowed;
      background-color: var(--vt-c-divider-dark-2);
    }
  }
}

@media (min-width: 1024px) {
}
</style>
