<template>
  <div class="mainTitle">
    <h1 class="green">{{ msg }}</h1>
  </div>
</template>

<script setup>
defineProps({
  msg : {
    type : String,
    required : true
  }
})
</script>

<style scoped lang="scss">
.mainTitle {
   text-align: center;
  margin: 35px 0;

  @media (max-width: 980px) {
    text-align: left;
  }
}
</style>
