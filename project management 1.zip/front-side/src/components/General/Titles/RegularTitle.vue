<template>
  <h1 class="regularTitle">{{ msg }}</h1>
</template>

<script setup>
defineProps({
  msg : {
    type : String,
    required : true
  }
})
</script>

<style scoped lang="scss">
.regularTitle {
  text-align: center;
  color: var(--vt-c-indigo);
  margin-bottom: 20px;
}
</style>
