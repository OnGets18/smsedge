<template>
  <div class="modal">
    <component class="basicModalStyle" :is="modalType"></component>
  </div>
</template>

<script setup>
import EditTask from "@/components/Layouts/Modals/Types/EditProjectsModal.vue";
import { computed } from "vue";
import { useStore } from "@/stores/store.js";
import TasksListModal from "@/components/Layouts/Modals/Types/TasksListModal.vue";

const modalType = computed(() => {
  switch (useStore().editModalOpen.type) {
    case "EDIT":
      return EditTask;
    case "SHOW_TASKS":
      return TasksListModal;
  }
});
</script>

<style scoped lang="scss">
.modal {
  top: 0;
  left: 0;
  position: fixed;
  z-index: 2;
  background: rgba(35, 37, 35, 0.43);
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 15px;

  .basicModalStyle {
    width: 550px;
    background: white;
    border-radius: 20px;
    padding: 30px;
    max-height: 80%;
    overflow: auto;
    &::-webkit-scrollbar {
      display: none;
    }
  }
}
</style>
