<template>
  <div class="editTaskModalWrapper">
    <HeaderModal title="Edit Project" @close="closeModal" />

    <TaskInput @close="closeModal" />
  </div>
</template>

<script setup>
import TaskInput from "@/components/General/Inptus/ProjectEditInput.vue";
import HeaderModal from "@/components/Layouts/Modals/Components/Header/HeaderModal.vue";
import { useStore } from "@/stores/store.js";

const closeModal = () => {
  useStore().toggleEditModal(false);
};
</script>

<style scoped lang="scss">
.editTaskModalWrapper {
  .inputsWrapper {
    width: 100%;
    margin: 0 auto;

    .input {
      margin-bottom: 25px;

      label {
        text-align: left;
        display: block;
        margin-top: 10px;
        font-size: 14px;
      }
      input[type="text"] {
        width: 100%;
        padding: 12px 20px;
        margin: 8px 0;
        display: inline-block;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
      }
    }

    input[type="submit"] {
      background-color: var(--gereen-style-cust-1);
      color: white;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      border-radius: 20px;
      cursor: pointer;
      width: 256px;
    }
  }
}
</style>
