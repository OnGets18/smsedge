<template>
  <div class="tasksWrapper">
    <HeaderModal title="Task List" @close="closeModal" />

    <div class="listWrapper">
      <div class="task" v-for="(task, index) in tasksList">
        <span v-text="`${index + 1}. ${task.task_name}`" />
      </div>
    </div>
  </div>
</template>

<script setup>
import HeaderModal from "@/components/Layouts/Modals/Components/Header/HeaderModal.vue";
import { useStore } from "@/stores/store.js";
import { computed } from "vue";

const closeModal = () => {
  useStore().toggleEditModal(false);
};

const tasksList = computed(() => {
  console.log(useStore()?.selectionProject);
  return useStore()?.selectionProject.tasksList;
});
</script>

<style scoped lang="scss">
.tasksWrapper {
  .listWrapper {
    display: flex;
    flex-direction: column;
    padding: 0 20px;
    font-weight: 800;
    .task {
      margin: 20px 0;
    }
  }
}
</style>
