<template>
  <div class="headerModalWrapper">
    <div class="title" v-text="title" />
    <DynamicIcon
      class="closeModalBtn"
      name="close"
      size="22"
      @click="handleClose"
    />
  </div>
</template>

<script setup>
import DynamicIcon from "@/components/Icons/DynamicIcon.vue";

defineProps({
  title: { type: String, required: true },
});
const emit = defineEmits(["close"]);

const handleClose = () => {
  emit("close");
};
</script>

<style scoped lang="scss" src="./HeaderModal.scss" />
