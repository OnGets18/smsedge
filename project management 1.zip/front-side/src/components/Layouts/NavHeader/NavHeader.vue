<template>
  <nav class="navItemsWrapper">
    <RouterLink to="/">HOME PAGE</RouterLink>
    <RouterLink to="/projects-list">PROJECTS LIST</RouterLink>
    <RouterLink to="/add-project">ADD NEW PROJECT</RouterLink>
  </nav>
</template>


<script setup>
import { RouterLink } from 'vue-router'
</script>

<style scoped lang="scss">
.navItemsWrapper {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  background-color: var(--vt-c-indigo);
  height: 95px;
  padding: 0 35px;

  a {
    text-decoration: none;
    font-weight: bold;
    color: hsla(160, 100%, 37%, 1);
    transition: 0.6s;
    padding: 15px;
    border-radius: 20px;

    &:hover, &.router-link-exact-active {
      background-color: hsla(160, 100%, 37%, 0.2);
    }
  }

}

@media (min-width: 1024px) {

}
</style>
