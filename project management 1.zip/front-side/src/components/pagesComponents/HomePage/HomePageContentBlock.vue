<template>
  <div class="homePageContentBlock">
    <h1 v-text="title" />
    <div v-text="paragraph" />
    <hr />
  </div>
</template>

<script setup>
defineProps({
  title: { type: String, required: true },
  paragraph: { type: String, required: true },
});
</script>

<style scoped lang="scss" src="./HomePageContentBlock.scss" />
