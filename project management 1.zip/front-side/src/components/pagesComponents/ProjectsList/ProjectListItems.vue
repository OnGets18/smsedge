<template>
  <div class="listWrapper">
    <div class="inputsWrapper">
      <DynamicIcon name="search" />

      <input
        class="searchInput"
        v-model="searchQuery"
        placeholder="Search by project name"
      />
    </div>

    <ProjectItem
      v-for="project in filteredList"
      :id="project.id"
      :title="project.name"
      :desc="project.desc"
    />
  </div>
</template>

<script setup>
import ProjectItem from "@/components/pagesComponents/ProjectsList/ProjectItem/ProjectItem.vue";
import { computed, ref } from "vue";
import { useStore } from "@/stores/store.js";
import DynamicIcon from "@/components/Icons/DynamicIcon.vue";
const store = useStore();
const searchQuery = ref("");

const list = computed(() => {
  return store.projectList;
});

const filteredList = computed(() => {
  if (!searchQuery.value.trim()) {
    return list.value;
  }
  const searchRegex = new RegExp(
    searchQuery.value
      .trim()
      .toLowerCase()
      .split(/\s+/)
      .map((word) => `\\b${word}`)
      .join("\\b.*\\b"),
  );
  return list.value.filter((project) =>
    searchRegex.test(project.name.toLowerCase()),
  );
});
</script>

<style lang="scss" src="./ProjectListItems.scss" />
