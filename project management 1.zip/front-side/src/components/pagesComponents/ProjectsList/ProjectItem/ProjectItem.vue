<template>
  <div class="itemWrapper">
    <div class="left">
      <DynamicIcon name="cubes" size="30"/>
      <div class="contentWrapper">
        <h1 class="title" v-text="title" />
        <div class="desc" v-text="desc" />
      </div>
    </div>

    <div class="actionsBtn">
      <span
        class="action showTasksBtn"
        @click="openModal('SHOW_TASKS')"
        v-text="'SHOW TASKS'"
      />
      <span class="action" @click="openModal('EDIT')">Edit</span>
      <span class="action delete" @click="removeProject">Delete</span>
    </div>
  </div>
</template>
<script setup>
import { useStore } from "@/stores/store.js";
import DynamicIcon from "@/components/Icons/DynamicIcon.vue";

const props = defineProps({
  id: {
    type: String,
    required: true,
  },
  title: {
    type: String,
    required: true,
  },
  desc: {
    type: String,
    required: true,
  },
});

const openModal = (type) => {
  useStore().toggleEditModal(true, props.id, type);
};

const removeProject = () => {
  useStore().removeProject(props.id);
};
</script>

<style lang="scss" src="./ProjectItem.scss"></style>
