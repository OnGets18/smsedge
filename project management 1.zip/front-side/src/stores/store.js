import axios from "axios"; // Import axios for making HTTP requests
import { defineStore } from "pinia";
import websocketService from "@/services/websocketService/websocketService.js";

export const useStore = defineStore("storeId", {
  state: () => ({
    taskItemList: [],
    projectsListMap: new Map(),
    editModalOpen: { active: false, type: "" },
    selectionProjectId: "",
  }),

  getters: {
    projectList: (state) => {
      return Array.from(state.projectsListMap.entries()).map(([id, task]) => ({
        id: id,
        name: task.name,
        desc: task.desc,
      }));
    },
    selectionProject() {
      return this.projectsListMap.get(this.selectionProjectId);
    },
  },

  actions: {
    async initFromDb() {
      const response = await axios.get("http://localhost:3000/getProjectsList");
      console.log("init from db data => ", response.data);
      // todo: if have any problem with connect to server/ mongo can replace to mock data.
      // const dataFrmDd = [
      //   { id : "1", name : "project 1", desc : "project desc 1" },
      //   { id : "2", name : "project 2", desc : "project desc 2" },
      //   { id : "3", name : "project 3", desc : "project desc 3" },
      //   { id : "5", name : "project 4", desc : "project desc 4" },
      // ];
      // dataFrmDd.forEach((project) => {
      //   this.projectsListMap.set(project.id, {
      //     name : project.name,
      //     desc : project.desc,
      //   });
      // });

      response.data.forEach((project) => {
        this.projectsListMap.set(project._id, {
          name: project.name ?? "*Missing name Project",
          desc: project.desc,
          tasksList: project.tasks_list,
        });
      });
    },
    toggleEditModal(status, projectId = "", type = "") {
      this.editModalOpen.active = status;
      this.editModalOpen.type = type;
      this.selectionProjectId = projectId.toString();

      document.body.classList.toggle("noScroll", status);
    },
    async removeProject(projectId) {
      try {
        websocketService.sendMessage("removeProject", projectId);

        this.projectsListMap.delete(projectId);
      } catch (e) {
        console.log("removeProject error");
      }
    },
  },
});
