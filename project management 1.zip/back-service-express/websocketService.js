const mongoose = require('mongoose');
const { ObjectId } = require('mongodb');
const tty = require("node:tty");

class WebSocketService {
    static initialize(io) {
        this.io = io;
        this.io.on('connection', (socket) => {
            console.log('New client connected');

            socket.on('disconnect', () => {
                console.log('Client disconnected');
            });

            socket.on('newProject', async (data) => {
                try {
                    const collection = mongoose.connection.collection('project_details');
                    const result = await collection.insertOne(
                        {
                            name : data.name,
                            desc : data.desc,
                            tasks_list: data.tasks_list
                        }); // Insert new project
                    console.log('Received create newProject:', result);
                    data.id = result.insertedId;
                    this.emitMessage('newProject', data);
                } catch (err) {
                    res.status(500).send(err.message);
                }
            });

            socket.on('editProject', async (data) => {
                try {
                    const collection = mongoose.connection.collection('project_details');
                    await collection.updateOne(
                        { _id : new ObjectId(data.id)._id },
                        { $set : { name : data.name, desc : data.desc, tasks_list: data.tasks_list } }
                    );

                    console.log("update in mongo success");

                    this.emitMessage('editProject', data);
                }catch (e) {
                    console.log("error update in mongo");
                }

            });

            socket.on('removeProject', async (projectId) => {
                const collection = mongoose.connection.collection('project_details');
                try {
                    await collection.deleteOne({ _id : new ObjectId(projectId)._id });
                    console.log('Remove Received message:', projectId);
                    this.emitMessage('removeProject', projectId);
                }catch (e){
                    console.log("error remove project in mongo");
                }

            });
        });
    }

    static emitMessage(event, message) {
        if (this.io) {
            this.io.emit(event, message);
        } else {
            console.error('WebSocket server not initialized');
        }
    }
}

module.exports = WebSocketService;
