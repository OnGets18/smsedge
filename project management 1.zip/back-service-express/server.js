const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const WebSocketService = require('./websocketService');
const connectDB = require('./db');
const mongoose = require('mongoose');
const cors = require('cors');
const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
    cors: {
        origin: 'http://localhost:3001', // Your client URL
        methods: ['GET', 'POST'],
        credentials: true,
    },
});

// Initialize WebSocket service
WebSocketService.initialize(io);
// Connect to MongoDB
connectDB();
app.use(express.json());
app.use(cors({
    origin: 'http://localhost:3001', // Allow requests from this origin
    methods: ['GET', 'POST'], // Allow these HTTP methods
    credentials: true, // Allow credentials (cookies, authorization headers, etc.)
}));

app.get('/', (req, res) => {
    res.send('Hello World!');
});

app.get('/emit', (req, res) => {
    const data = req.query.k;
    console.log(data)

    WebSocketService.emitMessage('newProject', `${data} - Hello World!`);
    res.send('newProject emitted');

    WebSocketService.emitMessage('editProject', `${data} - Hello World!`);
    res.send('editProject emitted');

    WebSocketService.emitMessage('removeProject', `${data} - Hello World!`);
    res.send('editProject emitted');
});

// Create a specific endpoint to fetch data from 'sample_supplies.sales'
app.get('/getProjectsList', async (req, res) => {
    try {
        const collection = mongoose.connection.collection('project_details');
        const data = await collection.find({}).toArray();
        res.json(data);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// Endpoint to add a new project
app.post('/addProject', async (req, res) => {
    try {
        const { name, desc } = req.body; // Extract name and desc from request body
        const collection = mongoose.connection.collection('project_details');
        const result = await collection.insertOne({ name, desc }); // Insert new project
        console.log(result);
        res.json(result); // Return the inserted document
    } catch (err) {
        res.status(500).send(err.message);
    }
});

const PORT = 3000;
server.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
